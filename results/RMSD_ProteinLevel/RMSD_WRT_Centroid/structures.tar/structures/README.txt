Structures files for structural comparison.
The name of the file corresponds to the structures in the file.
The CRL-bound structures are not provided and are  personal communications, but results from the comparisons are provided here. 
