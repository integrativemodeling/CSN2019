import os, sys
import numpy as np

ss = []

with open(sys.argv[1], 'r') as ifile:
    for line in ifile:
        tmp = [float(l) for l in line.strip().split(" ")]
        ss.append(tmp)

#print(len(ss), len(ss[0]))
ss = np.array(ss)

ss_1d = ss.flatten()
idx_1d = ss_1d.argsort()[-100:]
x_idx, y_idx = np.unravel_index(idx_1d, ss.shape)

for x, y, in zip(x_idx, y_idx):
    print(x, y, ss[x][y])
